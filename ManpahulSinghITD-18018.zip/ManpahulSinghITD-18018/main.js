/*script*/

var cd = 10;
//var asd = document.getElementById('dispp').innerHTML;

function countdown()
{
    document.getElementById('rkt').style.display = "none";
    if(cd > 0)
        {
            cd--;
            
            if(cd == 0)
                {
                    document.getElementById('dispp').innerHTML = '<br>' + 'BLAST OFF!!!';
                }
             else
                {
                    document.getElementById('dispp').innerHTML = '<br>' +  cd + '.....';
                }
        }
}