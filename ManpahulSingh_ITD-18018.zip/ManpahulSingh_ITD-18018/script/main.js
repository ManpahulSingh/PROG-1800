/*Script*/

/*Vars: 
sh - navigation
toggler - navigation
score - Counts and displays result
checkit - Checkin it
uuu - ifbewi
*/

var sh = document.getElementsByClassName("showhide");
var toggler = 0;
var score = 0;

var correctanswers = ["a", "b", "c", "c", "d", "b", "a", "c", "d", "a"];

function starat()
{
    document.getElementsByClassName("alwaysshow").style.display = "block";
    document.getElementsByClassName("yaya").style.display = "none";
}

function nxt()
{
    if(toggler < 11)
        {
            toggler++;
        }
    
    for(var i = 0; i < sh.length; i++)
        {
            if(i==toggler)
                {
                    sh[i].style.display = "block";
                }
            
            else
                {
                    sh[i].style.display = "none";
                }
        }
}

function prev()
{
    
    if(toggler>0)
        {
            toggler--;
        }
    
    for(var i = 0; i < sh.length; i++)
        {
            if(i==toggler)
                {
                    sh[i].style.display = "block";
                }
            
            else
                {
                    sh[i].style.display = "none";
                }
        }
}
/*

function checker()
{
    var checkit = new Array(10);
    
    var uuu = document.getElementsByClassName("anasar").value;
    
    var aaaaa = 0;
    
    for(var bb = 0; bb <40; bb++)
        {
           if(uuu[bb].checked)
               {
                    uuu[bb] = checkit[aaaaa];
               }
            
            if(bb%4 == 0)
                {
                    aaaaa++;
                }
        }

    counts marks
    for(var aa = 0; aa < 10; aa++)
        {
            if(checkit[aa]==correctanswers[aa])
                {
                    score++;
                }
        }
    
    alert(score);
    
}

*/

function checker()
{
                var b=document.quiz.ans1.value;
				var c=document.quiz.ans2.value;
				var d=document.quiz.ans3.value;
				var e=document.quiz.ans4.value;
				var f=document.quiz.ans5.value;
				var g=document.quiz.ans6.value;
				var h=document.quiz.ans7.value;
				var i=document.quiz.ans8.value;
				var j=document.quiz.ans9.value;
				var k=document.quiz.ans10.value;
				var a=0;
				
				if(b=="a")
				{a++;}
				if(c=="b")
				{a++;}
				if(d=="c")
				{a++;}
				if(e=="c")
				{a++;}
				if(f=="d")
				{a++;}
				if(g=="b")
				{a++;}
				if(h=="a")
				{a++;}
				if(i=="c")
				{a++;}
				if(j=="d")
				{a++;}
				if(k=="a")
				{a++;}	
				
				if(a==10)
				{
					alert("YOU HAVE SCORED "+a+" EXCELLENT");
				}
				else if(a<5)
				{
					alert("YOU HAVE SCORED "+a+" WORK HARD");
				}
				else if(a>=5)
				{
					alert("YOU HAVE SCORED "+a+" GOOD PERFORMANCE");
				}
}

